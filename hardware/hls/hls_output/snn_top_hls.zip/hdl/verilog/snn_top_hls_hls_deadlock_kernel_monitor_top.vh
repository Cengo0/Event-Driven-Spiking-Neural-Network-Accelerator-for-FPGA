
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [4:0] axis_block_sigs;
wire [1:0] inst_idle_sigs;
wire [0:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~s_axis_spikes_TDATA_blk_n;
assign axis_block_sigs[1] = ~s_axis_weights_TDATA_blk_n;
assign axis_block_sigs[2] = ~m_axis_spikes_TDATA_blk_n;
assign axis_block_sigs[3] = ~m_axis_weights_TDATA_blk_n;
assign axis_block_sigs[4] = ~grp_snn_top_hls_Pipeline_LOAD_FRAME_fu_1498.s_axis_data_TDATA_blk_n;

assign inst_block_sigs[0] = 1'b0;

assign inst_idle_sigs[0] = 1'b0;
assign inst_idle_sigs[1] = grp_snn_top_hls_Pipeline_LOAD_FRAME_fu_1498.ap_idle;

snn_top_hls_hls_deadlock_idx0_monitor snn_top_hls_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
